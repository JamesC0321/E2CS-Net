# Copyright (c) MONAI Consortium
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import logging
import os
import sys
import tempfile
from glob import glob
import torch.nn.functional as F
import torch

from torch.utils.tensorboard import SummaryWriter
import numpy
import monai

from monai.data import create_test_image_2d, list_data_collate, decollate_batch, DataLoader,PILReader
from FetalandMREC.TransUNet_vssm_v2.D2SNet import D2SNet
from monai.metrics import DiceMetric
from monai.transforms import (
    Activations,
    EnsureChannelFirstd,
    AsDiscrete,
    Compose,
    LoadImaged,
    RandCoarseShuffled,
    RandFlipDict,
    RandRotateDict,
    ScaleIntensityd,
)
from monai.visualize import plot_2d_or_3d_image

# 固定随机种子
def set_random_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    numpy.random.seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
def record_print(prt,record):
    print(prt)
    record.write(f"{prt},\n")


def main(tempdir):
    set_random_seed(2024)
    monai.config.print_config()
    logging.basicConfig(stream=sys.stdout, level=logging.INFO)



    images = sorted(glob(os.path.join('/media/chen/F/MREC/data/MREC/02split_data/train', "*.png")))
    segs = sorted(glob(os.path.join('/media/chen/F/MREC/data/MREC/02split_data/train_mask', "*_label.png")))

    images_val = sorted(glob(os.path.join('/media/chen/F/MREC/data/MREC/02split_data/val', "*.png")))
    segs_val = sorted(glob(os.path.join('/media/chen/F/MREC/data/MREC/02split_data/val_mask', "*_label.png")))



    train_files = [{"img": img, "seg": seg} for img, seg in zip(images, segs)]
    val_files = [{"img": img, "seg": seg} for img,seg in zip(images_val, segs_val)]


    train_transforms = Compose(
        [
            LoadImaged(keys=["img","seg"]),
            EnsureChannelFirstd(keys=["img", "seg"]),
            ScaleIntensityd(keys=["img", "seg"]),
            RandFlipDict(keys=["img", "seg"], prob=0.5, spatial_axis=1),
            RandFlipDict(keys=["img", "seg"], prob=0.5, spatial_axis=0),
            RandRotateDict(keys=["img", "seg"], range_x=(-45, 45), prob=0.3),
            RandCoarseShuffled(keys=["img"], holes=16, spatial_size=8, prob=1),

        ]
    )
    val_transforms = Compose(
        [
            LoadImaged(keys=["img", "seg"]),
            EnsureChannelFirstd(keys=["img", "seg"]),
            ScaleIntensityd(keys=["img","seg"]),

        ]
    )

    # define dataset, data loader
    check_ds = monai.data.Dataset(data=train_files, transform=train_transforms)
    # use batch_size=2 to load images and use RandCropByPosNegLabeld to generate 2 x 4 images for network training
    check_loader = DataLoader(check_ds, batch_size=2, num_workers=4, collate_fn=list_data_collate)
    check_data = monai.utils.misc.first(check_loader)
    print(check_data["img"].shape, check_data["seg"].shape)

    # create a training data loader
    train_ds = monai.data.Dataset(data=train_files, transform=train_transforms)
    # use batch_size=2 to load images and use RandCropByPosNegLabeld to generate 2 x 4 images for network training
    train_loader = DataLoader(
        train_ds,
        batch_size=10,
        shuffle=True,
        num_workers=4,
        collate_fn=list_data_collate,
        pin_memory=torch.cuda.is_available(),
    )
    # create a validation data loader
    val_ds = monai.data.Dataset(data=val_files, transform=val_transforms)
    val_loader = DataLoader(val_ds, batch_size=1, num_workers=4,shuffle=True, collate_fn=list_data_collate)
    dice_metric = DiceMetric(include_background=True, reduction="mean", get_not_nans=False)
    post_trans = Compose([Activations(sigmoid=True), AsDiscrete(threshold=0.5)])
    # create UNet, DiceLoss and Adam optimizer
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    model = D2SNet().to(device)


    loss_function = monai.losses.DiceCELoss(sigmoid=True)
    optimizer = torch.optim.Adam(model.parameters(), 1e-3)  # 0.0001
    scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer, milestones=[50,100,150],gamma=0.10)
    # start a typical PyTorch training
    val_interval = 1
    best_metric = -1
    best_metric_epoch = -1
    epoch_loss_values = list()
    metric_values = list()
    writer = SummaryWriter(log_dir=tempdir)
    record_txt = open(f"{tempdir}/record_txt.txt","a+")

    patience = 20  # 早停的耐心值
    no_improvement_count = 0  # 连续没有提升的次数

    ss = [0, 1, 2, 3]
    for epoch in range(200):
        print("-" * 10)
        print(f"epoch {epoch + 1}/{200}")
        model.train()
        epoch_loss = 0
        step = 0
        for batch_data in train_loader:
            step += 1
            inputs ,labels = batch_data["img"].to(device), batch_data["seg"].to(device)

            optimizer.zero_grad()

            outputs = model(inputs)
            loss = loss_function(outputs, labels)


            dice_outputs = post_trans(outputs)
            # compute metric for current iteration
            dice_metric(y_pred=dice_outputs, y=labels)
            loss.backward()
            optimizer.step()
            torch.cuda.empty_cache()
            #
            epoch_loss += loss.item()

        epoch_loss /= step
        scheduler.step()
        torch.cuda.empty_cache()
        epoch_loss_values.append(epoch_loss)
        dice_metric_ = dice_metric.aggregate().item()
        record_print(f"epoch {epoch + 1} average loss: {epoch_loss:.4f}",record_txt)
        writer.add_scalar("train_loss", epoch_loss, epoch+1)
        writer.add_scalar("train_mean_dice", dice_metric_, epoch + 1)
        record_print(f"epoch {epoch + 1} average train_dice_metric: {dice_metric_:.4f}",record_txt)
        dice_metric.reset()
        if (epoch + 1) % val_interval == 0:
            model.eval()
            with torch.no_grad():
                val_images = None
                val_labels = None
                val_outputs = None
                for val_data in val_loader:
                    val_images, val_labels = val_data["img"].to(device), val_data["seg"].to(device)


                    val_outputs = model(val_images)

                    val_outputs = post_trans(val_outputs)
                    # compute metric for current iteration
                    dice_metric(y_pred=val_outputs, y=val_labels)
                # aggregate the final mean dice result
                metric = dice_metric.aggregate().item()
                # reset the status for next validation round
                dice_metric.reset()
                torch.save(model.state_dict(), f"{tempdir}/last_epoch_model_segmentation2d_dict.pth")
                metric_values.append(metric)
                if metric > best_metric:
                    best_metric = metric
                    best_metric_epoch = epoch + 1
                    torch.save(model.state_dict(), f"{tempdir}/best_metric_model_segmentation2d_dict.pth")
                    print("saved new best metric model")
                    no_improvement_count = 0  # 重置计数器
                else:
                    no_improvement_count += 1  # 增加计数器
                record_print(
                    "current epoch: {} current mean dice: {:.4f} best mean dice: {:.4f} at epoch {}".format(
                        epoch + 1, metric, best_metric, best_metric_epoch
                    ),record_txt
                )
                writer.add_scalar("val_mean_dice", metric, epoch + 1)
                # plot the last model output as GIF image in TensorBoard with the corresponding image and label
                plot_2d_or_3d_image(val_images[0], epoch + 1, writer, index=0, tag="image")
                plot_2d_or_3d_image(val_labels[0], epoch + 1, writer, index=0, tag="label")
                plot_2d_or_3d_image(val_outputs[0], epoch + 1, writer, index=0, tag="output")
                # 早停检查
                if no_improvement_count >= patience:
                    record_print(f"Early stopping triggered after {no_improvement_count} epochs without improvement.",record_txt)
                    break
    record_print(f"train completed, best_metric: {best_metric:.4f} at epoch: {best_metric_epoch}",record_txt)
    writer.close()


if __name__ == "__main__":
    with tempfile.TemporaryDirectory() as tempdir:
        main('./FetalandMREC/run_data_ECFD/D2SNet')
